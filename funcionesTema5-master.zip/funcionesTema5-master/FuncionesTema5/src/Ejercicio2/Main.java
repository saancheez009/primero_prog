package Ejercicio2;

import java.util.Arrays;

public class Main {

	public static void main(String[] args) {
		int tabla []=new int [10];
		int maximo = 0;
		
	
		maximo=Ejercicio2.maximo(tabla);
		
		System.out.println("El máximo de la TABLA es " +maximo );
	}

}
