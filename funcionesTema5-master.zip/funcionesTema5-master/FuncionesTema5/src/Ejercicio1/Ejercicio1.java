package Ejercicio1;

import java.util.Arrays;

public class Ejercicio1 {

	
	
	public static long suma(int[] tabla) {
			
			long suma=0;
			
			for(long elemento: tabla) {
				suma+=elemento;
				//
			}
			
			
			return suma;
			
	
		}
	}


