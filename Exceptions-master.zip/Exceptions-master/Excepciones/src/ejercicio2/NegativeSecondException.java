package ejercicio2;

public class NegativeSecondException {
	public String getMessage() {
		return "Cantidad de segundos errónea";
	}

}