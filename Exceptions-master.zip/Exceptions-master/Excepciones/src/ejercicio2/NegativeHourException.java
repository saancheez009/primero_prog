package ejercicio2;

public class NegativeHourException {
	
	public String getMessage() {
		return "Cantidad de horas errónea";
	}
	
}
