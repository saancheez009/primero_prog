package ejercicio2;

public class NegativeMinuteException {

public String getMessage() {
	return "Cantidad de minutos errónea";
	}

}
