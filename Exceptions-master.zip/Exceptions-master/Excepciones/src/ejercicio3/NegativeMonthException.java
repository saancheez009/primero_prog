package ejercicio3;

public class NegativeMonthException {

	public String getMessage() {
		return "Cantidad de meses negativo";
	}
	
}
