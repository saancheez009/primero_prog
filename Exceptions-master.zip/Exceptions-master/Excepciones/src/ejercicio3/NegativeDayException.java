package ejercicio3;

public class NegativeDayException {
	
	public String getMessage() {
		return "Cantidad de dias negativo";
	}
	
}