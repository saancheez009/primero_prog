package ejercicio3;

public class NegativeYearException {
	public String getMessage() {
		return "Cantidad de años negativo";
	}
	
}