package ejercicio1;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc= new Scanner (System.in);
		
		//Mostramos por pantalla las funciones
		System.out.println(Utils.readDouble(sc));
		System.out.println();
		System.out.println(Utils.readInt(sc));
		
	}

}
