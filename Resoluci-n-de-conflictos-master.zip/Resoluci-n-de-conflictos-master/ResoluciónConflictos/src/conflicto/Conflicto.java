package conflicto;

public class Conflicto {

	public static void main(String[] args) {
		System.out.println("Hola, zoy er Juanma Sánchez");
		
		
		System.out.println("Hola, zoy la Brity Sánchez");

	}

}
