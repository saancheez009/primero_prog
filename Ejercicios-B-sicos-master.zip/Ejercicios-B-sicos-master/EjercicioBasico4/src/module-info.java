/**
 * 
 */
/**
 * @author bsanchez
 *
 */
module EjercicioBasico4 {
}