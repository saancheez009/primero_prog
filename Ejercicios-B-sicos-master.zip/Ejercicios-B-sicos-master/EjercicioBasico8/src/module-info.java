/**
 * 
 */
/**
 * @author bsanchez
 *
 */
module EjercicioBasico8 {
}