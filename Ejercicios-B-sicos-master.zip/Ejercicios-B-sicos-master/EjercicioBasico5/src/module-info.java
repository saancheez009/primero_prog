/**
 * 
 */
/**
 * @author bsanchez
 *
 */
module EjercicioBasico5 {
}