/**
 * 
 */
/**
 * @author bsanchez
 *
 */
module Ejerciciobasico3 {
}