/**
 * 
 */
/**
 * @author bsanchez
 *
 */
module EjercicioBasico6 {
}