/**
 * 
 */
/**
 * @author bsanchez
 *
 */
module EjercicioBasico7 {
}