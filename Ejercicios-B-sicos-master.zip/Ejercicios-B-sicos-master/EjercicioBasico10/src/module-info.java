/**
 * 
 */
/**
 * @author bsanchez
 *
 */
module EjercicioBasico10 {
}