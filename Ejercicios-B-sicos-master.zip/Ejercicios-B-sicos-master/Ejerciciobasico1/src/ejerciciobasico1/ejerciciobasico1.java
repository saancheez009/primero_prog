package ejerciciobasico1;

public class ejerciciobasico1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.print("Hello, how are you?");
        System.out.println("Fine thanks.");

	}

}
