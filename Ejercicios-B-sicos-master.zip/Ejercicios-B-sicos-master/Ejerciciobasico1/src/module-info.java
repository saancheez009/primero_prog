/**
 * 
 */
/**
 * @author bsanchez
 *
 */
module Ejerciciobasico1 {
}