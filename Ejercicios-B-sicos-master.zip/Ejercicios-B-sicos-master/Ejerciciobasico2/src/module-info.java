/**
 * 
 */
/**
 * @author bsanchez
 *
 */
module Ejerciciobasico2 {
}