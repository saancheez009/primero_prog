package EjerciciosFor;

public class Ejercicio3 {

	public static void main(String[] args) {
		
		//Mediante for introducimos la i y le damos valor 7 para luego sumarle 7 y que solo se muestren los múltiplos de 7
		for (int i=7 ; i<=100; i=i+7) {
			System.out.println(i); //Mostramos los múltiplos de 7 menores que 100 ya que al introducir i<=100 en el for ponemos la condición que se muestren solo los múltiplos de 7 menores a 100
		

	}

}
}