package EjerciciosFor;

public class Ejercicio2 {

	public static void main(String[] args) {
		
		
		//Mediante for declaramos i=2 para mostrar números pares y sumamos 2 consecutivamente
		for (int i=2 ; i>=1 && i<=200; i=i+2) { //Para delimitar hasta que número mostramos pares declaramos que nos muestre números comprendidios entre 1 y 200 con i>=1 && i<=200 
			System.out.println(i);
			//Le mostramos al usuario los números pares comprendidios entre 1 y 200
		
	}

	}
}