package ejercicio3;

public class Main {

	public static void main(String[] args) {
		Fecha fecha = new Fecha (06,11,2003);
		fecha.fechaCorrecta();
		fecha.diaSiguiente();
		System.out.println(fecha.toString());

	}

}
