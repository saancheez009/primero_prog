package Ejercicio4;

public class Operaciones {

		int suma;
		int resta;
		int multiplicacion;
		int division;
		
	int suma (int num1,int num2) {
		suma= num1+num2;
		
		return suma;
	}
	
	int resta (int num1, int num2) {
		resta=num1-num2;
		
		return resta;
	}
	
	int multiplicacion (int num1, int num2) {
		multiplicacion=num1*num2;
		
		return multiplicacion;
		
	}
	
	int division (int num1, int num2) {
		division=num1/num2;
		
		return division;
	}

}
