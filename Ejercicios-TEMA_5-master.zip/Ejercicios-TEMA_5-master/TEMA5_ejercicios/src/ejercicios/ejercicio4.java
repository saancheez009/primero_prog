package ejercicios;

public class ejercicio4 {

	public static void main(String[] args) {
		
		int tabla[]=new int [12];
		
		tabla[0]=39;
		tabla[1]=-2;
		tabla[4]=0;
		tabla[6]=14;
		tabla[8]=5;
		tabla[9]=120;
		
		for(int valor: tabla) {
			System.out.println(valor);
		}

	}

}
