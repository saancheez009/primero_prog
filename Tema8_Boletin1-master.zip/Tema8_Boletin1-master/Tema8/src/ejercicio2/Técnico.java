package ejercicio2;

public class Técnico extends Operario{

	public Técnico(String nombre) {
		super(nombre);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return super.toString()+"-> Técnico";
	}

	
}
