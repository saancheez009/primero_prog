package ejercicio2;

public class Operario extends Empleado{

	

	public Operario(String nombre) {
		super(nombre);
		// TODO Auto-generated constructor stub
	}
	
	

	/**
	 * Método toString
	 */
	@Override
	public String toString() {
		return super.toString()+"-> Operario";
	}

	
}
