package ejercicio2;

public class Directivo extends Empleado{
	
	

	public Directivo(String nombre) {
		super(nombre);
		// TODO Auto-generated constructor stub
	}


	@Override
	public String toString() {
		// TODO Auto-generated method stub
		
		
		return super.toString()+"-> Directivo";
	
	
	}
}
