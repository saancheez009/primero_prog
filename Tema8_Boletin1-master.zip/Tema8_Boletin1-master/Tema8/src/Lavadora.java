
public class Lavadora {

}
