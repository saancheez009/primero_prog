package ejercicios;

public class Ejercicio9 {

	public static void main(String[] args) {
		
		
	}

}
