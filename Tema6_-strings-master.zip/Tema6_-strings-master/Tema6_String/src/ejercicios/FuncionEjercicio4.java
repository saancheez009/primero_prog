package ejercicios;

public class FuncionEjercicio4 {

	
		
		static  String  alReves (String frase, String fraseInversa) {
			
			for(int i=frase.length()-1;i>=0;i--) {
				
				fraseInversa+=frase.charAt(i);
				
									
				
		}
			return frase;
			
		}

	

}
