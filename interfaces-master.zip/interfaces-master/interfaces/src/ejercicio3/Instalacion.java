package ejercicio3;

public class Instalacion {
	public default int getTipoDeInstalacion() {
	      return 0;
	  }
}
