package ejercicio3;

public class Edificio {
	public default double getSuperficieEdificio() {
       return 0;
    }
}
