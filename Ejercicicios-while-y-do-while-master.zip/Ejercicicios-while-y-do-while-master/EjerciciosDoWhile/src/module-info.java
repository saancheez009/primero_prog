module EjerciciosDoWhile {
}