module EjerciciosWhile {
}